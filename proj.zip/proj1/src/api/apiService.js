const API_URL = "https://run.mocky.io/v3/6cee870e-47bd-45b7-8650-8c171b6984b5";

export const fetchData = async () => {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    const data = await response.json();
    return data.assets;
  } catch (error) {
    console.error("Failed to fetch data:", error);
    throw error;
  }
};
