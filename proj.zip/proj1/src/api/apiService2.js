export async function fetchData() {
  try {
    const response = await fetch(
      "https://run.mocky.io/v3/6cee870e-47bd-45b7-8650-8c171b6984b5"
    );
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching data:", error);
    return null;
  }
}
