import React, { useState, useEffect } from "react";
import { fetchData } from "./api/apiService2";
import "./Block.css";
import Block1 from "./Blocks/Block1";
import Block2 from "./Blocks/Block2";
import Block3 from "./Blocks/Block3";
const Block = ({ onBlockClick }) => {
  const [data, setData] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      const fetchedData = await fetchData();
      setData(fetchedData);
    };

    loadData();
  }, []);

  if (!data) {
    return <div>Loading...</div>;
  }
  const { cloud, domain, ip } = data;

  return (
    <div className="container">
      <Block1 domain={domain} onClick={() => onBlockClick("domain")} />
      <Block2 ip={ip} onClick={() => onBlockClick("ip")} />
      <Block3 cloud={cloud} onClick={() => onBlockClick("cloud")} />
    </div>
  );
};

export default Block;
