import React from "react";
import "../Block.css";
import { ReactComponent as CloudSVG } from "../svg/Group 3.svg";
import { ReactComponent as Arrow } from "../svg/arrow.svg";
import { ReactComponent as Ips } from "../svg/Group 4.svg";
import { ReactComponent as PortSVG } from "../svg/Group 5.svg";
import { ReactComponent as Vulns } from "../svg/Group 6.svg";
import { ReactComponent as Graph } from "../svg/graph.svg";

const Block3 = ({ cloud, onClick }) => {
  return (
    <div className="container" onClick={onClick}>
      <div className="box box-1">
        <div className="container1">
          <div className="row">
            <div className="column span-2">
              <CloudSVG width="60" height="60" />
            </div>
            <div className="column span-3"></div>
            <div className="column">
              <Arrow width="30" height="30" />
            </div>
          </div>
          <h5>
            Cloud Accounts <hr class="divider" />
          </h5>
          <div className="row">
            <div className="column">
              <h4>Live {cloud.total_live}</h4>
            </div>
            <div className="column span-2">
              <Graph />
            </div>
            <div className="column">
              <h4>Monitored {cloud.total_monitored}</h4>
            </div>
            <div className="column span-2">
              <Graph />
            </div>
          </div>
          <hr class="divider1" />
          <div className="row">
            <div className="column">
              <Ips width="60" height="60" />
            </div>
            <div className="column">
              <h5>
                IPs <br />
                {cloud.ips}
              </h5>
            </div>
            <div className="column">
              <PortSVG width="60" height="60" />
            </div>
            <div className="column">
              <h5>Ports {cloud.ports}</h5>
            </div>
            <div className="column">
              <Vulns width="60" height="60" />
            </div>
            <div className="column">
              <h5>Vulns {cloud.vulns}</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Block3;
