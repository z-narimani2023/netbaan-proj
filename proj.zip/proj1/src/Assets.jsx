import React from "react";
import "./assets.css";
import { ReactComponent as Grade } from "./svg/grade.svg";

const SvgBackground = ({ item }) => {
  if (!item || typeof item.grade === "undefined") {
    return <div>No grade available</div>;
  }

  return <div className="svg-background">{item.grade}</div>;
};

const assets = ({ data, selectedBlock }) => {
  if (!Array.isArray(data)) {
    return <p>No data available</p>;
  }
  const filteredData = selectedBlock
    ? data.filter((item) => item.type === selectedBlock)
    : data;
  return (
    <table>
      <caption>
        <h4>Assets</h4>
      </caption>
      <thead>
        <tr>
          <th id="grade">Grade</th>
          <th id="name">Name</th>
          <th>Total Vulnerabilities</th>
          <th>Last Seen</th>
        </tr>
      </thead>
      <tbody>
        {filteredData.map((item, index) => (
          <tr key={index}>
            <td id="grade">
              {" "}
              <SvgBackground item={item} />
            </td>
            <td id="name">{item.name}</td>
            <td>{item.total_vuls}</td>{" "}
            <td>{new Date(item.lastSeen).toLocaleString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default assets;
