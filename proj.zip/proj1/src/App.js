import React, { useState, useEffect } from "react";
import { fetchData } from "./api/apiService";
import TableComponent from "./Assets";
import Blocks from "./Block";
const App = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedBlock, setSelectedBlock] = useState(null);
  useEffect(() => {
    const getData = async () => {
      try {
        const result = await fetchData();
        setData(result);
        setLoading(false);
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    };

    getData();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <div className="App">
      <div className="Blocks">
        <Blocks onBlockClick={setSelectedBlock} />
      </div>
      <div className="assets">
        <TableComponent data={data} selectedBlock={selectedBlock} />
      </div>
    </div>
  );
};

export default App;
